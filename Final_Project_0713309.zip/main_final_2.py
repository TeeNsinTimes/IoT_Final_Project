import kivy
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.slider import Slider
from kivy.uix.floatlayout import FloatLayout
from kivy.core.window import Window
from kivy.uix.textinput import TextInput
from kivy.uix.label import Label
from kivy.graphics import Color, Rectangle
from kivy.uix.checkbox import CheckBox
from kivy.storage.jsonstore import JsonStore

from datetime import datetime
import math
import time
import http.client, urllib
import json
import requests
import socket
import certifi as cfi

# Set MediaTek Cloud Sandbox (MCS) Key
deviceId = "DDDwb30y"
deviceKey = "9OwRj2V29xCtXVyw"

store = JsonStore('hello.json')

'''
for item in store.find(name='Set_Time_Val'):
    print('value pairs are', str(item[1]))
'''

def get_temperature():
    host = "http://api.mediatek.com"
    endpoint = "/mcs/v2/devices/" + deviceId + "/datachannels/temperature/datapoints"
    url = host + endpoint
    headers = {"Content-type": "application/json", "deviceKey": deviceKey}
    r = requests.get(url,headers=headers)
    value = (r.json()["dataChannels"][0]["dataPoints"][0]["values"]["value"])
    return value
    
def get_humidity():
    host = "http://api.mediatek.com"
    endpoint = "/mcs/v2/devices/" + deviceId + "/datachannels/humidity/datapoints"
    url = host + endpoint
    headers = {"Content-type": "application/json", "deviceKey": deviceKey}
    r = requests.get(url,headers=headers)
    value = (r.json()["dataChannels"][0]["dataPoints"][0]["values"]["value"])
    return value

def get_battery():
    host = "http://api.mediatek.com"
    endpoint = "/mcs/v2/devices/" + deviceId + "/datachannels/battery/datapoints"
    url = host + endpoint
    headers = {"Content-type": "application/json", "deviceKey": deviceKey}
    r = requests.get(url,headers=headers)
    value = (r.json()["dataChannels"][0]["dataPoints"][0]["values"]["value"])
    return value
    
def get_lightness():
    host = "http://api.mediatek.com"
    endpoint = "/mcs/v2/devices/" + deviceId + "/datachannels/light/datapoints"
    url = host + endpoint
    headers = {"Content-type": "application/json", "deviceKey": deviceKey}
    r = requests.get(url,headers=headers)
    value = (r.json()["dataChannels"][0]["dataPoints"][0]["values"]["value"])
    return value
    
def get_moisture():
    host = "http://api.mediatek.com"
    endpoint = "/mcs/v2/devices/" + deviceId + "/datachannels/moisture/datapoints"
    url = host + endpoint
    headers = {"Content-type": "application/json", "deviceKey": deviceKey}
    r = requests.get(url,headers=headers)
    value = (r.json()["dataChannels"][0]["dataPoints"][0]["values"]["value"])
    return value

def get_settings():
    host = "http://api.mediatek.com"
    endpoint = "/mcs/v2/devices/" + deviceId + "/datachannels/time/datapoints"
    url = host + endpoint
    headers = {"Content-type": "application/json", "deviceKey": deviceKey}
    r = requests.get(url,headers=headers)
    value = (r.json()["dataChannels"][0]["dataPoints"][0]["values"]["value"])
    return value

settings = get_settings().split('\n')

assign_light=True
if (store.exists('act1')):
    assign_light = store.get('act1')['Vals']
    
assign_humid=True
if (store.exists('act2')):
    assign_humid = store.get('act2')['Vals']

def on_checkbox_active1(checkbox, value):
    store.put('act1', name='Set_Time_Val', Vals=value)
    global assign_light
    if value:
        wid1.ids.container_x.disabled = False
        assign_light=True
        ##print('The checkbox', checkbox, 'is active')
    else:
        wid1.ids.container_x.disabled = True
        assign_light=False
        ##print('The checkbox', checkbox, 'is inactive')

def on_checkbox_active2(checkbox, value):
    store.put('act2', name='Set_Time_Val', Vals=value)
    global assign_humid
    if value:
        wid2.ids.container_x.disabled = False
        assign_humid=True
        ##print('The checkbox', checkbox, 'is active')
    else:
        wid2.ids.container_x.disabled = True
        assign_humid=False
        ##print('The checkbox', checkbox, 'is inactive')

class MyLabel(Label):
    def on_size(self, *args):
        self.canvas.before.clear()
        with self.canvas.before:
            Color(0, 0, 0, 0)
            Rectangle(pos=self.pos, size=self.size)
        
class MainWid(BoxLayout):
    def __init__(self, *args):
        super(MainWid, self).__init__()

        if args[6] == 0:
            global text_bar1, text_bar2, text_bar3, text_bar4, text_bar5, text_bar6, text_bar7, text_bar8
            global text_bar9, text_bar10, text_bar11, text_bar12, text_bar13, text_bar14, text_bar15, text_bar16
            global text_bar17, text_bar18, text_bar19, text_bar20, text_bar21, text_bar22, text_bar23, text_bar24
            global bar1, bar2, bar3, bar4, bar5, bar6, bar7, bar8, bar9, bar10, bar11, bar12
            global bar13, bar14, bar15, bar16, bar17, bar18, bar19, bar20, bar21, bar22, bar23, bar24

            layout1 = BoxLayout(orientation = "vertical")

            label1 = MyLabel(
                text='00:00-\n01:00',
                size_hint=(args[0], args[1]))
            layout1.add_widget(label1)

            val1 = 0
            if(store.exists('hey1')):
                val1 = int(store.get('hey1')['Vals'])

            bar1 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val1
            )
            bar1.bind(value = self.on_value1)

            layout1.add_widget(bar1)
        
            text_bar1 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar1.text = str(val1)
            layout1.add_widget(text_bar1)
        
            self.ids.container_x.add_widget(layout1)
        
            layout2 = BoxLayout(orientation = "vertical")
        
            label2 = MyLabel(
                text='01:00-\n02:00',
                size_hint=(args[0], args[1]))
            layout2.add_widget(label2)

            val2 = 0
            if(store.exists('hey2')):
                val2 = int(store.get('hey2')['Vals'])

            bar2 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val2
            )
            bar2.bind(value = self.on_value2)
            layout2.add_widget(bar2)
        
            text_bar2 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar2.text = str(val2)
            layout2.add_widget(text_bar2)
        
            self.ids.container_x.add_widget(layout2)
        
            layout3 = BoxLayout(orientation = "vertical")
        
            label3 = MyLabel(
                text='02:00-\n03:00',
                size_hint=(args[0], args[1]))
            layout3.add_widget(label3)

            val3 = 0
            if(store.exists('hey3')):
                val3 = int(store.get('hey3')['Vals'])

            bar3 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val3
            )
            bar3.bind(value = self.on_value3)
            layout3.add_widget(bar3)
        
            text_bar3 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar3.text = str(val3)
            layout3.add_widget(text_bar3)
        
            self.ids.container_x.add_widget(layout3)

            layout4 = BoxLayout(orientation = "vertical")
        
            label4 = MyLabel(
                text='03:00-\n04:00',
                size_hint=(args[0], args[1]))
            layout4.add_widget(label4)

            val4 = 0
            if(store.exists('hey4')):
                val4 = int(store.get('hey4')['Vals'])

            bar4 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val4
            )
            bar4.bind(value = self.on_value4)
            layout4.add_widget(bar4)
        
            text_bar4 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar4.text = str(val4)
            layout4.add_widget(text_bar4)
        
            self.ids.container_x.add_widget(layout4)

            layout5 = BoxLayout(orientation = "vertical")
        
            label5 = MyLabel(
                text='04:00-\n05:00',
                size_hint=(args[0], args[1]))
            layout5.add_widget(label5)

            val5 = 0
            if(store.exists('hey5')):
                val5 = int(store.get('hey5')['Vals'])

            bar5 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val5
            )
            bar5.bind(value = self.on_value5)
            layout5.add_widget(bar5)
        
            text_bar5 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar5.text = str(val5)
            layout5.add_widget(text_bar5)
        
            self.ids.container_x.add_widget(layout5)

            layout6 = BoxLayout(orientation = "vertical")
        
            label6 = MyLabel(
                text='05:00-\n06:00',
                size_hint=(args[0], args[1]))
            layout6.add_widget(label6)

            val6 = 0
            if(store.exists('hey6')):
                val6 = int(store.get('hey6')['Vals'])

            bar6 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val6
            )
            bar6.bind(value = self.on_value6)
            layout6.add_widget(bar6)
        
            text_bar6 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar6.text = str(val6)
            layout6.add_widget(text_bar6)
        
            self.ids.container_x.add_widget(layout6)

            layout7 = BoxLayout(orientation = "vertical")

            label7 = MyLabel(
                text='06:00-\n07:00',
                size_hint=(args[0], args[1]))
            layout7.add_widget(label7)

            val7 = 0
            if(store.exists('hey7')):
                val7 = int(store.get('hey7')['Vals'])

            bar7 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val7
            )
            bar7.bind(value = self.on_value7)
            layout7.add_widget(bar7)
        
            text_bar7 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar7.text = str(val7)
            layout7.add_widget(text_bar7)
        
            self.ids.container_x.add_widget(layout7)
        
            layout8 = BoxLayout(orientation = "vertical")
        
            label8 = MyLabel(
                text='07:00-\n08:00',
                size_hint=(args[0], args[1]))
            layout8.add_widget(label8)

            val8 = 0
            if(store.exists('hey8')):
                val8 = int(store.get('hey8')['Vals'])

            bar8 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val8
            )
            bar8.bind(value = self.on_value8)
            layout8.add_widget(bar8)
        
            text_bar8 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar8.text = str(val8)
            layout8.add_widget(text_bar8)
        
            self.ids.container_x.add_widget(layout8)
        
            layout9 = BoxLayout(orientation = "vertical")
        
            label9 = MyLabel(
                text='08:00-\n09:00',
                size_hint=(args[0], args[1]))
            layout9.add_widget(label9)

            val9 = 0
            if(store.exists('hey9')):
                val9 = int(store.get('hey9')['Vals'])

            bar9 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val9
            )
            bar9.bind(value = self.on_value9)
            layout9.add_widget(bar9)
        
            text_bar9 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar9.text = str(val9)
            layout9.add_widget(text_bar9)
        
            self.ids.container_x.add_widget(layout9)

            layout10 = BoxLayout(orientation = "vertical")
        
            label10 = MyLabel(
                text='09:00-\n10:00',
                size_hint=(args[0], args[1]))
            layout10.add_widget(label10)

            val10 = 0
            if(store.exists('hey10')):
                val10 = int(store.get('hey10')['Vals'])

            bar10 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val10
            )
            bar10.bind(value = self.on_value10)
            layout10.add_widget(bar10)
        
            text_bar10 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar10.text = str(val10)
            layout10.add_widget(text_bar10)
        
            self.ids.container_x.add_widget(layout10)

            layout11 = BoxLayout(orientation = "vertical")
        
            label11 = MyLabel(
                text='10:00-\n11:00',
                size_hint=(args[0], args[1]))
            layout11.add_widget(label11)

            val11 = 0
            if(store.exists('hey11')):
                val11 = int(store.get('hey11')['Vals'])

            bar11 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val11
            )
            bar11.bind(value = self.on_value11)
            layout11.add_widget(bar11)
        
            text_bar11 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar11.text = str(val11)
            layout11.add_widget(text_bar11)
        
            self.ids.container_x.add_widget(layout11)

            layout12 = BoxLayout(orientation = "vertical")
        
            label12 = MyLabel(
                text='11:00-\n12:00',
                size_hint=(args[0], args[1]))
            layout12.add_widget(label12)

            val12 = 0
            if(store.exists('hey12')):
                val12 = int(store.get('hey12')['Vals'])

            bar12 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val12
            )
            bar12.bind(value = self.on_value12)
            layout12.add_widget(bar12)
        
            text_bar12 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar12.text = str(val12)
            layout12.add_widget(text_bar12)
        
            self.ids.container_x.add_widget(layout12)

            layout13 = BoxLayout(orientation = "vertical")

            label13 = MyLabel(
                text='12:00-\n13:00',
                size_hint=(args[0], args[1]))
            layout13.add_widget(label13)

            val13 = 0
            if(store.exists('hey13')):
                val13 = int(store.get('hey13')['Vals'])

            bar13 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val13
            )
            bar13.bind(value = self.on_value13)
            layout13.add_widget(bar13)
        
            text_bar13 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar13.text = str(val13)
            layout13.add_widget(text_bar13)
        
            self.ids.container_x.add_widget(layout13)
        
            layout14 = BoxLayout(orientation = "vertical")
        
            label14 = MyLabel(
                text='13:00-\n14:00',
                size_hint=(args[0], args[1]))
            layout14.add_widget(label14)

            val14 = 0
            if(store.exists('hey14')):
                val14 = int(store.get('hey14')['Vals'])

            bar14 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val14
            )
            bar14.bind(value = self.on_value14)
            layout14.add_widget(bar14)
        
            text_bar14 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar14.text = str(val14)
            layout14.add_widget(text_bar14)
        
            self.ids.container_x.add_widget(layout14)
        
            layout15 = BoxLayout(orientation = "vertical")
        
            label15 = MyLabel(
                text='14:00-\n15:00',
                size_hint=(args[0], args[1]))
            layout15.add_widget(label15)

            val15 = 0
            if(store.exists('hey15')):
                val15 = int(store.get('hey15')['Vals'])

            bar15 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val15
            )
            bar15.bind(value = self.on_value15)
            layout15.add_widget(bar15)
        
            text_bar15 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar15.text = str(val15)
            layout15.add_widget(text_bar15)
        
            self.ids.container_x.add_widget(layout15)

            layout16 = BoxLayout(orientation = "vertical")
        
            label16 = MyLabel(
                text='15:00-\n16:00',
                size_hint=(args[0], args[1]))
            layout16.add_widget(label16)

            val16 = 0
            if(store.exists('hey16')):
                val16 = int(store.get('hey16')['Vals'])

            bar16 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val16
            )
            bar16.bind(value = self.on_value16)
            layout16.add_widget(bar16)
        
            text_bar16 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar16.text =str(val16)
            layout16.add_widget(text_bar16)
        
            self.ids.container_x.add_widget(layout16)

            layout17 = BoxLayout(orientation = "vertical")
        
            label17 = MyLabel(
                text='16:00-\n17:00',
                size_hint=(args[0], args[1]))
            layout17.add_widget(label17)

            val17 = 0
            if(store.exists('hey17')):
                val17 = int(store.get('hey17')['Vals'])

            bar17 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val17
            )
            bar17.bind(value = self.on_value17)
            layout17.add_widget(bar17)
        
            text_bar17 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar17.text = str(val17)
            layout17.add_widget(text_bar17)
        
            self.ids.container_x.add_widget(layout17)

            layout18 = BoxLayout(orientation = "vertical")
        
            label18 = MyLabel(
                text='17:00-\n18:00',
                size_hint=(args[0], args[1]))
            layout18.add_widget(label18)

            val18 = 0
            if(store.exists('hey18')):
                val18 = int(store.get('hey18')['Vals'])

            bar18 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val18
            )
            bar18.bind(value = self.on_value18)
            layout18.add_widget(bar18)
        
            text_bar18 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar18.text = str(val18)
            layout18.add_widget(text_bar18)
        
            self.ids.container_x.add_widget(layout18)

            layout19 = BoxLayout(orientation = "vertical")

            label19 = MyLabel(
                text='18:00-\n19:00',
                size_hint=(args[0], args[1]))
            layout19.add_widget(label19)

            val19 = 0
            if(store.exists('hey19')):
                val19 = int(store.get('hey19')['Vals'])

            bar19 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val19
            )
            bar19.bind(value = self.on_value19)
            layout19.add_widget(bar19)
        
            text_bar19 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar19.text = str(val19)
            layout19.add_widget(text_bar19)
        
            self.ids.container_x.add_widget(layout19)
        
            layout20 = BoxLayout(orientation = "vertical")
        
            label20 = MyLabel(
                text='19:00-\n20:00',
                size_hint=(args[0], args[1]))
            layout20.add_widget(label20)

            val20 = 0
            if(store.exists('hey20')):
                val20 = int(store.get('hey20')['Vals'])

            bar20 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val20
            )
            bar20.bind(value = self.on_value20)
            layout20.add_widget(bar20)
        
            text_bar20 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar20.text = str(val20)
            layout20.add_widget(text_bar20)
        
            self.ids.container_x.add_widget(layout20)
        
            layout21 = BoxLayout(orientation = "vertical")
        
            label21 = MyLabel(
                text='20:00-\n21:00',
                size_hint=(args[0], args[1]))
            layout21.add_widget(label21)

            val21 = 0
            if(store.exists('hey21')):
                val21 = int(store.get('hey21')['Vals'])

            bar21 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val21
            )
            bar21.bind(value = self.on_value21)
            layout21.add_widget(bar21)
        
            text_bar21 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar21.text = str(val21)
            layout21.add_widget(text_bar21)
        
            self.ids.container_x.add_widget(layout21)

            layout22 = BoxLayout(orientation = "vertical")
        
            label22 = MyLabel(
                text='21:00-\n22:00',
                size_hint=(args[0], args[1]))
            layout22.add_widget(label22)

            val22 = 0
            if(store.exists('hey22')):
                val22 = int(store.get('hey22')['Vals'])

            bar22 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val22
            )
            bar22.bind(value = self.on_value22)
            layout22.add_widget(bar22)
        
            text_bar22 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar22.text = str(val22)
            layout22.add_widget(text_bar22)
        
            self.ids.container_x.add_widget(layout22)

            layout23 = BoxLayout(orientation = "vertical")
        
            label23 = MyLabel(
                text='22:00-\n23:00',
                size_hint=(args[0], args[1]))
            layout23.add_widget(label23)

            val23 = 0
            if(store.exists('hey23')):
                val23 = int(store.get('hey23')['Vals'])

            bar23 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val23
            )
            bar23.bind(value = self.on_value23)
            layout23.add_widget(bar23)
        
            text_bar23 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar23.text = str(val23)
            layout23.add_widget(text_bar23)
        
            self.ids.container_x.add_widget(layout23)

            layout24 = BoxLayout(orientation = "vertical")
        
            label24 = MyLabel(
                text='23:00-\n24:00',
                size_hint=(args[0], args[1]))
            layout24.add_widget(label24)

            val24 = 0
            if(store.exists('hey24')):
                val24 = int(store.get('hey24')['Vals'])

            bar24 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                value = val24
            )
            bar24.bind(value = self.on_value24)
            layout24.add_widget(bar24)
        
            text_bar24 = TextInput(
                multiline=False, readonly=True, halign="center", font_size=80,
                size_hint=(args[4], args[5])
            )
            text_bar24.text = str(val24)
            layout24.add_widget(text_bar24)
        
            self.ids.container_x.add_widget(layout24)
        else:
            '''
            val1 = 0
            if(store.exists('bye1')):
                val1 = int(store.get('bye1')['Vals'])
            '''
            global humids
            humids=[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            for i in range(24):
                if (store.exists('bye'+str(i+1))):
                    humids[i] = int(store.get('bye'+str(i+1))['Vals'])
            global bar_1, bar_2, bar_3, bar_4, bar_5, bar_6, bar_7, bar_8, bar_9, bar_10, bar_11, bar_12
            global bar_13, bar_14, bar_15, bar_16, bar_17, bar_18, bar_19, bar_20, bar_21, bar_22, bar_23, bar_24

            layout1 = BoxLayout(orientation = "vertical")

            label1 = MyLabel(
                text='00:00-\n01:00',
                size_hint=(args[0], args[1])
                )
            layout1.add_widget(label1)

            bar_1 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[0]
            )
            bar_1.bind(value = self.on_off1)
            layout1.add_widget(bar_1)
        
            self.ids.container_x.add_widget(layout1)
        
            layout2 = BoxLayout(orientation = "vertical")
        
            label2 = MyLabel(
                text='01:00-\n02:00',
                size_hint=(args[0], args[1]))
            layout2.add_widget(label2)

            bar_2 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[1]
            )
            bar_2.bind(value = self.on_off2)
            layout2.add_widget(bar_2)
        
            self.ids.container_x.add_widget(layout2)
        
            layout3 = BoxLayout(orientation = "vertical")
        
            label3 = MyLabel(
                text='02:00-\n03:00',
                size_hint=(args[0], args[1]))
            layout3.add_widget(label3)

            bar_3 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[2]
            )
            bar_3.bind(value = self.on_off3)
            layout3.add_widget(bar_3)
        
            self.ids.container_x.add_widget(layout3)

            layout4 = BoxLayout(orientation = "vertical")
        
            label4 = MyLabel(
                text='03:00-\n04:00',
                size_hint=(args[0], args[1]))
            layout4.add_widget(label4)

            bar_4 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[3]
            )
            bar_4.bind(value = self.on_off4)
            layout4.add_widget(bar_4)
        
            self.ids.container_x.add_widget(layout4)

            layout5 = BoxLayout(orientation = "vertical")
        
            label5 = MyLabel(
                text='04:00-\n05:00',
                size_hint=(args[0], args[1]))
            layout5.add_widget(label5)

            bar_5 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[4]
            )
            #print(bar_5.value)
            bar_5.bind(value = self.on_off5)
            layout5.add_widget(bar_5)

            self.ids.container_x.add_widget(layout5)

            layout6 = BoxLayout(orientation = "vertical")
        
            label6 = MyLabel(
                text='05:00-\n06:00',
                size_hint=(args[0], args[1]))
            layout6.add_widget(label6)

            bar_6 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[5]
            )
            bar_6.bind(value = self.on_off6)
            layout6.add_widget(bar_6)
        
            self.ids.container_x.add_widget(layout6)

            layout7 = BoxLayout(orientation = "vertical")

            label7 = MyLabel(
                text='06:00-\n07:00',
                size_hint=(args[0], args[1]))
            layout7.add_widget(label7)

            bar_7 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[6]
            )
            bar_7.bind(value = self.on_off7)
            layout7.add_widget(bar_7)
        
            self.ids.container_x.add_widget(layout7)
        
            layout8 = BoxLayout(orientation = "vertical")
        
            label8 = MyLabel(
                text='07:00-\n08:00',
                size_hint=(args[0], args[1]))
            layout8.add_widget(label8)

            bar_8 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[7]
            )
            bar_8.bind(value = self.on_off8)
            layout8.add_widget(bar_8)
        
            self.ids.container_x.add_widget(layout8)
        
            layout9 = BoxLayout(orientation = "vertical")
        
            label9 = MyLabel(
                text='08:00-\n09:00',
                size_hint=(args[0], args[1]))
            layout9.add_widget(label9)

            bar_9 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[8]
            )
            bar_9.bind(value = self.on_off9)
            layout9.add_widget(bar_9)
        
            self.ids.container_x.add_widget(layout9)

            layout10 = BoxLayout(orientation = "vertical")
        
            label10 = MyLabel(
                text='09:00-\n10:00',
                size_hint=(args[0], args[1]))
            layout10.add_widget(label10)

            bar_10 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[9]
            )
            bar_10.bind(value = self.on_off10)
            layout10.add_widget(bar_10)
        
            self.ids.container_x.add_widget(layout10)

            layout11 = BoxLayout(orientation = "vertical")
        
            label11 = MyLabel(
                text='10:00-\n11:00',
                size_hint=(args[0], args[1]))
            layout11.add_widget(label11)

            bar_11 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[10]
            )
            bar_11.bind(value = self.on_off11)
            layout11.add_widget(bar_11)
        
            self.ids.container_x.add_widget(layout11)

            layout12 = BoxLayout(orientation = "vertical")
        
            label12 = MyLabel(
                text='11:00-\n12:00',
                size_hint=(args[0], args[1]))
            layout12.add_widget(label12)

            bar_12 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[11]
            )
            bar_12.bind(value = self.on_off12)
            layout12.add_widget(bar_12)
        
            self.ids.container_x.add_widget(layout12)

            layout13 = BoxLayout(orientation = "vertical")

            label13 = MyLabel(
                text='12:00-\n13:00',
                size_hint=(args[0], args[1]))
            layout13.add_widget(label13)

            bar_13 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[12]
            )
            bar_13.bind(value = self.on_off13)
            layout13.add_widget(bar_13)
        
            self.ids.container_x.add_widget(layout13)
        
            layout14 = BoxLayout(orientation = "vertical")
        
            label14 = MyLabel(
                text='13:00-\n14:00',
                size_hint=(args[0], args[1]))
            layout14.add_widget(label14)

            bar_14 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[13]
            )
            bar_14.bind(value = self.on_off14)
            layout14.add_widget(bar_14)
        
            self.ids.container_x.add_widget(layout14)
        
            layout15 = BoxLayout(orientation = "vertical")
        
            label15 = MyLabel(
                text='14:00-\n15:00',
                size_hint=(args[0], args[1]))
            layout15.add_widget(label15)

            bar_15 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[14]
            )
            bar_15.bind(value = self.on_off15)
            layout15.add_widget(bar_15)
        
            self.ids.container_x.add_widget(layout15)

            layout16 = BoxLayout(orientation = "vertical")
        
            label16 = MyLabel(
                text='15:00-\n16:00',
                size_hint=(args[0], args[1]))
            layout16.add_widget(label16)

            bar_16 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[15]
            )
            bar_16.bind(value = self.on_off16)
            layout16.add_widget(bar_16)

            self.ids.container_x.add_widget(layout16)

            layout17 = BoxLayout(orientation = "vertical")
        
            label17 = MyLabel(
                text='16:00-\n17:00',
                size_hint=(args[0], args[1]))
            layout17.add_widget(label17)

            bar_17 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[16]
            )
            bar_17.bind(value = self.on_off17)
            layout17.add_widget(bar_17)
        
            self.ids.container_x.add_widget(layout17)

            layout18 = BoxLayout(orientation = "vertical")
        
            label18 = MyLabel(
                text='17:00-\n18:00',
                size_hint=(args[0], args[1]))
            layout18.add_widget(label18)

            bar_18 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[17]
            )
            bar_18.bind(value = self.on_off18)
            layout18.add_widget(bar_18)
        
            self.ids.container_x.add_widget(layout18)

            layout19 = BoxLayout(orientation = "vertical")

            label19 = MyLabel(
                text='18:00-\n19:00',
                size_hint=(args[0], args[1]))
            layout19.add_widget(label19)

            bar_19 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[18]
            )
            bar_19.bind(value = self.on_off19)
            layout19.add_widget(bar_19)
        
            self.ids.container_x.add_widget(layout19)
        
            layout20 = BoxLayout(orientation = "vertical")
        
            label20 = MyLabel(
                text='19:00-\n20:00',
                size_hint=(args[0], args[1]))
            layout20.add_widget(label20)

            bar_20 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[19]
            )
            bar_20.bind(value = self.on_off20)
            layout20.add_widget(bar_20)
        
            self.ids.container_x.add_widget(layout20)
        
            layout21 = BoxLayout(orientation = "vertical")
        
            label21 = MyLabel(
                text='20:00-\n21:00',
                size_hint=(args[0], args[1]))
            layout21.add_widget(label21)

            bar_21 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[20]
            )
            bar_21.bind(value = self.on_off21)
            layout21.add_widget(bar_21)
        
            self.ids.container_x.add_widget(layout21)

            layout22 = BoxLayout(orientation = "vertical")
        
            label22 = MyLabel(
                text='21:00-\n22:00',
                size_hint=(args[0], args[1]))
            layout22.add_widget(label22)

            bar_22 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[21]
            )
            bar_22.bind(value = self.on_off22)
            layout22.add_widget(bar_22)
        
            self.ids.container_x.add_widget(layout22)

            layout23 = BoxLayout(orientation = "vertical")
        
            label23 = MyLabel(
                text='22:00-\n23:00',
                size_hint=(args[0], args[1]))
            layout23.add_widget(label23)

            bar_23 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[22]
            )
            bar_23.bind(value = self.on_off23)
            layout23.add_widget(bar_23)
        
            self.ids.container_x.add_widget(layout23)

            layout24 = BoxLayout(orientation = "vertical")
        
            label24 = MyLabel(
                text='23:00-\n24:00',
                size_hint=(args[0], args[1]))
            layout24.add_widget(label24)

            bar_24 = Slider(
                min = args[2], max = args[3], step = 1,
                orientation ='vertical',
                value_track = True,
                value_track_color =[137/255, 196/255, 244/255, 1],
                cursor_width = 300,
                cursor_image = "rect2.jpeg",
                size_hint = (1, 0.5),
                value = humids[23]
            )
            bar_24.bind(value = self.on_off24)
            layout24.add_widget(bar_24)
        
            self.ids.container_x.add_widget(layout24)
        
    def on_value1(self, instance, val):
        #print(str(int(val)))
        text_bar1.text = str(int(val))
        store.put('hey1', name='Set_Time_Val', Vals=val)
        bar2.value = val
        
    def on_value2(self, instance, val):
        #print(str(int(val)))
        text_bar2.text = str(int(val))
        store.put('hey2', name='Set_Time_Val', Vals=val)
        bar3.value = val
        
    def on_value3(self, instance, val):
        #print(str(int(val)))
        text_bar3.text = str(int(val))
        store.put('hey3', name='Set_Time_Val', Vals=val)
        bar4.value = val

    def on_value4(self, instance, val):
        #print(str(int(val)))
        text_bar4.text = str(int(val))
        store.put('hey4', name='Set_Time_Val', Vals=val)
        bar5.value = val

    def on_value5(self, instance, val):
        #print(str(int(val)))
        text_bar5.text = str(int(val))
        store.put('hey5', name='Set_Time_Val', Vals=val)
        bar6.value = val

    def on_value6(self, instance, val):
        #print(str(int(val)))
        text_bar6.text = str(int(val))
        store.put('hey6', name='Set_Time_Val', Vals=val)
        bar7.value = val
    
    def on_value7(self, instance, val):
        #print(str(int(val)))
        text_bar7.text = str(int(val))
        store.put('hey7', name='Set_Time_Val', Vals=val)
        bar8.value = val
        
    def on_value8(self, instance, val):
        #print(str(int(val)))
        text_bar8.text = str(int(val))
        store.put('hey8', name='Set_Time_Val', Vals=val)
        bar9.value = val
        
    def on_value9(self, instance, val):
        #print(str(int(val)))
        text_bar9.text = str(int(val))
        store.put('hey9', name='Set_Time_Val', Vals=val)
        bar10.value = val

    def on_value10(self, instance, val):
        #print(str(int(val)))
        text_bar10.text = str(int(val))
        store.put('hey10', name='Set_Time_Val', Vals=val)
        bar11.value = val

    def on_value11(self, instance, val):
        #print(str(int(val)))
        text_bar11.text = str(int(val))
        store.put('hey11', name='Set_Time_Val', Vals=val)
        bar12.value = val

    def on_value12(self, instance, val):
        #print(str(int(val)))
        text_bar12.text = str(int(val))
        store.put('hey12', name='Set_Time_Val', Vals=val)
        bar13.value = val

    def on_value13(self, instance, val):
        #print(str(int(val)))
        text_bar13.text = str(int(val))
        store.put('hey13', name='Set_Time_Val', Vals=val)
        bar14.value = val
        
    def on_value14(self, instance, val):
        #print(str(int(val)))
        text_bar14.text = str(int(val))
        store.put('hey14', name='Set_Time_Val', Vals=val)
        bar15.value = val
        
    def on_value15(self, instance, val):
        #print(str(int(val)))
        text_bar15.text = str(int(val))
        store.put('hey15', name='Set_Time_Val', Vals=val)
        bar16.value = val

    def on_value16(self, instance, val):
        #print(str(int(val)))
        text_bar16.text = str(int(val))
        store.put('hey16', name='Set_Time_Val', Vals=val)
        bar17.value = val

    def on_value17(self, instance, val):
        #print(str(int(val)))
        text_bar17.text = str(int(val))
        store.put('hey17', name='Set_Time_Val', Vals=val)
        bar18.value = val

    def on_value18(self, instance, val):
        #print(str(int(val)))
        text_bar18.text = str(int(val))
        store.put('hey18', name='Set_Time_Val', Vals=val)
        bar19.value = val
    
    def on_value19(self, instance, val):
        #print(str(int(val)))
        text_bar19.text = str(int(val))
        store.put('hey19', name='Set_Time_Val', Vals=val)
        bar20.value = val
        
    def on_value20(self, instance, val):
        #print(str(int(val)))
        text_bar20.text = str(int(val))
        store.put('hey20', name='Set_Time_Val', Vals=val)
        bar21.value = val
        
    def on_value21(self, instance, val):
        #print(str(int(val)))
        text_bar21.text = str(int(val))
        store.put('hey21', name='Set_Time_Val', Vals=val)
        bar22.value = val

    def on_value22(self, instance, val):
        #print(str(int(val)))
        text_bar22.text = str(int(val))
        store.put('hey22', name='Set_Time_Val', Vals=val)
        bar23.value = val

    def on_value23(self, instance, val):
        #print(str(int(val)))
        text_bar23.text = str(int(val))
        store.put('hey23', name='Set_Time_Val', Vals=val)
        bar24.value = val

    def on_value24(self, instance, val):
        #print(str(int(val)))
        text_bar24.text = str(int(val))
        store.put('hey24', name='Set_Time_Val', Vals=val)

    def on_off1(self, instance, val):
        #print(str(int(val)))
        humids[0] = str(int(val))
        store.put('bye1', name='Set_Time_Val', Vals=val)
        bar_2.value = val
        
    def on_off2(self, instance, val):
        #print(str(int(val)))
        humids[1] = str(int(val))
        store.put('bye2', name='Set_Time_Val', Vals=val)
        bar_3.value = val
        
    def on_off3(self, instance, val):
        #print(str(int(val)))
        humids[2] = str(int(val))
        store.put('bye3', name='Set_Time_Val', Vals=val)
        bar_4.value = val

    def on_off4(self, instance, val):
        #print(str(int(val)))
        humids[3] = str(int(val))
        store.put('bye4', name='Set_Time_Val', Vals=val)
        bar_5.value = val

    def on_off5(self, instance, val):
        #print(str(int(val)))
        humids[4] = str(int(val))
        store.put('bye5', name='Set_Time_Val', Vals=val)
        bar_6.value = val

    def on_off6(self, instance, val):
        #print(str(int(val)))
        humids[5] = str(int(val))
        store.put('bye6', name='Set_Time_Val', Vals=val)
        bar_7.value = val
    
    def on_off7(self, instance, val):
        #print(str(int(val)))
        humids[6] = str(int(val))
        store.put('bye7', name='Set_Time_Val', Vals=val)
        bar_8.value = val
        
    def on_off8(self, instance, val):
        #print(str(int(val)))
        humids[7] = str(int(val))
        store.put('bye8', name='Set_Time_Val', Vals=val)
        bar_9.value = val
        
    def on_off9(self, instance, val):
        #print(str(int(val)))
        humids[8] = str(int(val))
        store.put('bye9', name='Set_Time_Val', Vals=val)
        bar_10.value = val

    def on_off10(self, instance, val):
        #print(str(int(val)))
        humids[9] = str(int(val))
        store.put('bye10', name='Set_Time_Val', Vals=val)
        bar_11.value = val

    def on_off11(self, instance, val):
        #print(str(int(val)))
        humids[10] = str(int(val))
        store.put('bye11', name='Set_Time_Val', Vals=val)
        bar_12.value = val

    def on_off12(self, instance, val):
        #print(str(int(val)))
        humids[11] = str(int(val))
        store.put('bye12', name='Set_Time_Val', Vals=val)
        bar_13.value = val

    def on_off13(self, instance, val):
        #print(str(int(val)))
        humids[12] = str(int(val))
        store.put('bye13', name='Set_Time_Val', Vals=val)
        bar_14.value = val
        
    def on_off14(self, instance, val):
        #print(str(int(val)))
        humids[13] = str(int(val))
        store.put('bye14', name='Set_Time_Val', Vals=val)
        bar_15.value = val
        
    def on_off15(self, instance, val):
        #print(str(int(val)))
        humids[14] = str(int(val))
        store.put('bye15', name='Set_Time_Val', Vals=val)
        bar_16.value = val

    def on_off16(self, instance, val):
        #print(str(int(val)))
        humids[15] = str(int(val))
        store.put('bye16', name='Set_Time_Val', Vals=val)
        bar_17.value = val

    def on_off17(self, instance, val):
        #print(str(int(val)))
        humids[16] = str(int(val))
        store.put('bye17', name='Set_Time_Val', Vals=val)
        bar_18.value = val

    def on_off18(self, instance, val):
        #print(str(int(val)))
        humids[17] = str(int(val))
        store.put('bye18', name='Set_Time_Val', Vals=val)
        bar_19.value = val
    
    def on_off19(self, instance, val):
        #print(str(int(val)))
        humids[18] = str(int(val))
        store.put('bye19', name='Set_Time_Val', Vals=val)
        bar_20.value = val
        
    def on_off20(self, instance, val):
        #print(str(int(val)))
        humids[19] = str(int(val))
        store.put('bye20', name='Set_Time_Val', Vals=val)
        bar_21.value = val
        
    def on_off21(self, instance, val):
        #print(str(int(val)))
        humids[20] = str(int(val))
        store.put('bye21', name='Set_Time_Val', Vals=val)
        bar_22.value = val

    def on_off22(self, instance, val):
        #print(str(int(val)))
        humids[21] = str(int(val))
        store.put('bye22', name='Set_Time_Val', Vals=val)
        bar_23.value = val

    def on_off23(self, instance, val):
        #print(str(int(val)))
        humids[22] = str(int(val))
        store.put('bye23', name='Set_Time_Val', Vals=val)
        bar_24.value = val

    def on_off24(self, instance, val):
        #print(str(int(val)))
        humids[23] = str(int(val))
        store.put('bye24', name='Set_Time_Val', Vals=val)
        
class MainApp(App):
    def build(self):
        layout = FloatLayout()
        
        label1 = MyLabel(
            text='Temperature',
            pos = (Window.size[0] * 0.0, Window.size[1] * 0.95),
            size_hint=(0.25, 0.05))
        layout.add_widget(label1)

        temperature = 0
        if (store.exists('tempe')):
            temperature = store.get('tempe')['Vals']

        self.text1 = TextInput(
            multiline=False, readonly=True, halign="center", font_size=80,
            pos = (Window.size[0] * 0.25, Window.size[1] * 0.95),
                size_hint=(0.25, 0.05))
        self.text1.text = str(temperature) + " °C"
        layout.add_widget(self.text1)
        
        label2 = MyLabel(
            text='Humidity',
            pos = (Window.size[0] * 0.5, Window.size[1] * 0.95),
            size_hint=(0.25, 0.05))
        layout.add_widget(label2)
        
        humidity = 0
        if (store.exists('humid')):
            humidity = store.get('humid')['Vals']

        self.text2 = TextInput(
            multiline=False, readonly=True, halign="center", font_size=80,
            pos = (Window.size[0] * 0.75, Window.size[1] * 0.95),
                size_hint=(0.25, 0.05))
        self.text2.text = str(humidity) + " %"
        layout.add_widget(self.text2)
        
        label3 = MyLabel(
            text='Battery',
            pos = (Window.size[0] * 0.0, Window.size[1] * 0.89),
            size_hint=(0.25, 0.05))
        layout.add_widget(label3)

        battery = 0
        if (store.exists('batte')):
            battery = store.get('batte')['Vals']
        
        self.text3 = TextInput(
            multiline=False, readonly=True, halign="center", font_size=80,
            pos = (Window.size[0] * 0.25, Window.size[1] * 0.89),
                size_hint=(0.25, 0.05))
        self.text3.text = str(battery) + " %"
        layout.add_widget(self.text3)
        
        label4 = MyLabel(
            text='Lightness',
            pos = (Window.size[0] * 0, Window.size[1] * 0.83),
            size_hint=(0.25, 0.05))
        layout.add_widget(label4)

        lightness = 0
        if (store.exists('light')):
            lightness = store.get('light')['Vals']
        
        self.text4 = TextInput(
            multiline=False, readonly=True, halign="center", font_size=80,
            pos = (Window.size[0] * 0.25, Window.size[1] * 0.83),
                size_hint=(0.25, 0.05))
        self.text4.text = str(lightness) + " %"
        layout.add_widget(self.text4)
        
        label5 = MyLabel(
            text='Soil Moisture',
            pos = (Window.size[0] * 0.5, Window.size[1] * 0.83),
            size_hint=(0.25, 0.05))
        layout.add_widget(label5)

        moisture = 0
        if (store.exists('moist')):
            moisture = store.get('moist')['Vals']
        
        self.text5 = TextInput(
            multiline=False, readonly=True, halign="center", font_size=80,
            pos = (Window.size[0] * 0.75, Window.size[1] * 0.83),
                size_hint=(0.25, 0.05))
        self.text5.text = str(moisture) + " %"
        layout.add_widget(self.text5)
        
        refresh_button = Button(
            text="Refresh",
            pos = (Window.size[0] * 0.05, Window.size[1] * 0.74),
                size_hint=(0.9, 0.08))
        refresh_button.bind(on_press=self.on_refresh_button_press)
        layout.add_widget(refresh_button)
        
        label_dash = MyLabel(
            text='-------------------------------------------------------------------------------------------------------------------------------------------',
            pos = (Window.size[0] * 0, Window.size[1] * 0.7),
            size_hint=(1, 0.05))
        layout.add_widget(label_dash)
        
        label6 = MyLabel(
            text='Assign Light',
            pos = (Window.size[0] * 0.04, Window.size[1] * 0.64),
            size_hint=(0.41, 0.1))
        layout.add_widget(label6)

        act1 = True
        if (store.exists('act1')):
            act1 = store.get('act1')['Vals']
        
        checkbox1 = CheckBox(
            color=(1, 1, 1, 1),
            pos = (Window.size[0] * 0.03, Window.size[1] * 0.64),
            size_hint=(0.1, 0.1),
            active=act1)
        checkbox1.bind(active=on_checkbox_active1)
        layout.add_widget(checkbox1)
        
        global wid1
        wid1 = MainWid(1, 0.25, 0, 100, 1, 0.2, 0)
        wid1.pos = (Window.size[0] * 0, Window.size[1] * 0.32)
        wid1.size_hint = (1, 0.35)
        layout.add_widget(wid1)

        if act1 == False:
            wid1.ids.container_x.disabled = True

        label7 = MyLabel(
            text='Assign Humidifier',
            pos = (Window.size[0] * 0.09, Window.size[1] * 0.24),
            size_hint=(0.41, 0.1))
        layout.add_widget(label7)
        
        act2 = True
        if (store.exists('act2')):
            act2 = store.get('act2')['Vals']

        checkbox2 = CheckBox(
            color=(1, 1, 1, 1),
            pos = (Window.size[0] * 0.03, Window.size[1] * 0.24),
            size_hint=(0.1, 0.1),
            active=act2)
        checkbox2.bind(active=on_checkbox_active2)
        layout.add_widget(checkbox2)

        global wid2
        wid2 = MainWid(1, 0.25, 0, 1, 0, 0, 1)
        wid2.pos = (Window.size[0] * 0, Window.size[1] * 0.11)
        wid2.size_hint = (1, 0.15)
        layout.add_widget(wid2)
        
        if act2 == False:
            wid2.ids.container_x.disabled = True

        change_settings_button = Button(
            text="Change Settings",
            pos = (Window.size[0] * 0.05, Window.size[1] * 0),
                size_hint=(0.9, 0.08))
        change_settings_button.bind(on_press=self.on_change_settings_button_press)
        layout.add_widget(change_settings_button)

        return layout
    
    def on_refresh_button_press(self, instance):
        temperature = int(get_temperature() * 10)/10
        humidity = int(get_humidity() * 10) / 10
        battery = int(get_battery())
        lightness = get_lightness()
        moisture = get_moisture()
        store.put('tempe', name='Set_Time_Val', Vals=temperature)
        store.put('humid', name='Set_Time_Val', Vals=humidity)
        store.put('batte', name='Set_Time_Val', Vals=battery)
        store.put('light', name='Set_Time_Val', Vals=lightness)
        store.put('moist', name='Set_Time_Val', Vals=moisture)
        self.text1.text = str(temperature) + " °C"
        self.text2.text = str(humidity) + " %"
        self.text3.text = str(battery) + " %"
        self.text4.text = str(lightness) + " %"
        self.text5.text = str(moisture) + " %"
    
    def on_change_settings_button_press(self, instance):
        payload = {"datapoints":[{"dataChnId":"time","values":{"value":
            str(assign_light)+'\n'+
            str(assign_humid)+'\n'+
            text_bar1.text+'\n'+
            text_bar2.text+'\n'+
            text_bar3.text+'\n'+
            text_bar4.text+'\n'+
            text_bar5.text+'\n'+
            text_bar6.text+'\n'+
            text_bar7.text+'\n'+
            text_bar8.text+'\n'+
            text_bar9.text+'\n'+
            text_bar10.text+'\n'+
            text_bar11.text+'\n'+
            text_bar12.text+'\n'+
            text_bar13.text+'\n'+
            text_bar14.text+'\n'+
            text_bar15.text+'\n'+
            text_bar16.text+'\n'+
            text_bar17.text+'\n'+
            text_bar18.text+'\n'+
            text_bar19.text+'\n'+
            text_bar20.text+'\n'+
            text_bar21.text+'\n'+
            text_bar22.text+'\n'+
            text_bar23.text+'\n'+
            text_bar24.text+'\n'+
            str(humids[0])+'\n'+
            str(humids[1])+'\n'+
            str(humids[2])+'\n'+
            str(humids[3])+'\n'+
            str(humids[4])+'\n'+
            str(humids[5])+'\n'+
            str(humids[6])+'\n'+
            str(humids[7])+'\n'+
            str(humids[8])+'\n'+
            str(humids[9])+'\n'+
            str(humids[10])+'\n'+
            str(humids[11])+'\n'+
            str(humids[12])+'\n'+
            str(humids[13])+'\n'+
            str(humids[14])+'\n'+
            str(humids[15])+'\n'+
            str(humids[16])+'\n'+
            str(humids[17])+'\n'+
            str(humids[18])+'\n'+
            str(humids[19])+'\n'+
            str(humids[20])+'\n'+
            str(humids[21])+'\n'+
            str(humids[22])+'\n'+
            str(humids[23])
            }}]}

        headers = {"Content-type": "application/json", "deviceKey": deviceKey}
        not_connected = 1
        while (not_connected):
            try:
                conn = http.client.HTTPConnection("api.mediatek.com:80")
                conn.connect()
                not_connected = 0
            except (http.client.HTTPException, socket.error) as ex:
                #print ("Error: %s" % ex)
                time.sleep(10) # sleep 10 seconds

        conn.request("POST", "/mcs/v2/devices/" + deviceId + "/datapoints", json.dumps(payload), headers)
        response = conn.getresponse()
        # #print(response.status, response.reason, json.dumps(payload), time.strftime("%c"))
        data = response.read()
        conn.close()
 
if __name__ == "__main__":
    MainApp().run()
