import pySmartGadget
import sys
import grove.i2c
from datetime import datetime
import RPi.GPIO as GPIO
import math
import time
import http.client, urllib
import json
import requests
import socket

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)
ledPin = 12
humidifierPin = 40
GPIO.setup(ledPin, GPIO.OUT)
GPIO.setup(humidifierPin, GPIO.OUT)

GPIO.output(humidifierPin,GPIO.LOW)

PWM_FREQ = 200
pwm = GPIO.PWM(ledPin, PWM_FREQ)
pwm.start(0)

pwm.ChangeDutyCycle(0)

def pwmled():
    host = "http://api.mediatek.com"
    endpoint = "/mcs/v2/devices/" + deviceId + "/datachannels/pwmled/datapoints"
    url = host + endpoint
    headers = {"Content-type": "application/json", "deviceKey": deviceKey}
    r = requests.get(url,headers=headers)
    value = (r.json()["dataChannels"][0]["dataPoints"][0]["values"]["value"])
    return value
    
def turn_on_humidifier():
    host = "http://api.mediatek.com"
    endpoint = "/mcs/v2/devices/" + deviceId + "/datachannels/humidifier/datapoints"
    url = host + endpoint
    headers = {"Content-type": "application/json", "deviceKey": deviceKey}
    r = requests.get(url,headers=headers)
    value = (r.json()["dataChannels"][0]["dataPoints"][0]["values"]["value"])
    return value

def get_settings():
    host = "http://api.mediatek.com"
    endpoint = "/mcs/v2/devices/" + deviceId + "/datachannels/time/datapoints"
    url = host + endpoint
    headers = {"Content-type": "application/json", "deviceKey": deviceKey}
    r = requests.get(url,headers=headers)
    value = (r.json()["dataChannels"][0]["dataPoints"][0]["values"]["value"])
    return value

__all__ = [
    "ADC",
    "RPI_HAT_NAME", "RPI_ZERO_HAT_NAME",
    "RPI_HAT_PID", "RPI_ZERO_HAT_PID"
]

RPI_HAT_PID      = 0x0004
RPI_ZERO_HAT_PID = 0x0005
RPI_HAT_NAME     = 'Grove Base Hat RPi'
RPI_ZERO_HAT_NAME= 'Grove Base Hat RPi Zero'

class ADC(object):
    def __init__(self, address = 0x04):
        self.address = address
        self.bus = grove.i2c.Bus()

    # input voltage / output voltage (%)
    def read(self, channel):
        addr = 0x30 + channel
        return self.read_register(addr)

    # read 16 bits register
    def read_register(self, n):
        try:
            self.bus.write_byte(self.address, n)
            return self.bus.read_word_data(self.address, n)
        except IOError:
            print("Check whether I2C enabled and   {}  or  {}  inserted".format \
                    (RPI_HAT_NAME, RPI_ZERO_HAT_NAME))
            sys.exit(2)
            return 0

# Set MediaTek Cloud Sandbox (MCS) Key
deviceId = "DDDwb30y"
deviceKey = "9OwRj2V29xCtXVyw"

# Set MediaTek Cloud Sandbox (MCS) Connection
def post_to_mcs(payload):
    headers = {"Content-type": "application/json", "deviceKey": deviceKey}
    not_connected = 1
    while (not_connected):
        try:
            conn = http.client.HTTPConnection("api.mediatek.com:80")
            conn.connect()
            not_connected = 0
        except (http.client.HTTPException, socket.error) as ex:
            print ("Error: %s" % ex)
            time.sleep(10) # sleep 10 seconds

    conn.request("POST", "/mcs/v2/devices/" + deviceId + "/datapoints", json.dumps(payload), headers)
    response = conn.getresponse()
    # print(response.status, response.reason, json.dumps(payload), time.strftime("%c"))
    data = response.read()
    conn.close()

bleAddress = 'E4:50:41:2C:9B:AC'
print('Connecting to:', bleAddress)
gadget = pySmartGadget.SHT31(bleAddress)
print('Connected')

# Post MediaTek Cloud Sandbox (MCS)
while True:
    adc = ADC();
    [temp, humidity, battery, light, soil] = [math.ceil(gadget.readTemperature()*100)/100, math.ceil(gadget.readHumidity()*100)/100, math.ceil(gadget.readBattery()*100)/100,
                                              adc.read(0)/10,
                                              (90-adc.read(2)/10)*2]
    print("temp = %.02f C humidity = %.02f%% battery level = %.02f%%"%(temp, humidity, battery))
    print("lightness = %.01f%% soil moisture = %.01f%%"%(light, soil))
    payload = {
        "datapoints":[
            {"dataChnId":"temperature","values":{"value":temp}},
            {"dataChnId":"humidity","values":{"value":humidity}},
            {"dataChnId":"battery","values":{"value":battery}},
            {"dataChnId":"light","values":{"value":str(light)}},
            {"dataChnId":"moisture","values":{"value":str(soil)}}
        ]
    }
    post_to_mcs(payload)
    time.sleep(5)
    
    now = datetime.now()
    current_time = now.strftime("%H:%M:%S").split(':')
    
    settings = get_settings().split('\n')
    
    if settings[0] == "True":
        print("Use Light Settings")
        val = int(settings[2+int(current_time[0])])
        print("LED lightness changing to level %d."%(val))
        pwm.ChangeDutyCycle(val)
    else:
        print("Change Lightness According to Environment")
        val = pwmled()
        print("LED lightness changing to level %d."%(val))
        pwm.ChangeDutyCycle(val)
        
    if settings[1] == "True":
        print("Use Humidity Settings")
        turn_on = int(settings[26+int(current_time[0])])
        if(turn_on == 1):
            print("Humidifier turning on.")
            GPIO.output(humidifierPin,GPIO.HIGH)
        else:
            print("Humidifier turning off.")
            GPIO.output(humidifierPin,GPIO.LOW)
    else:
        print("Turn on Humidifier According to Environment")
        if(turn_on_humidifier() == 1):
            print("Humidifier turning on.")
            GPIO.output(humidifierPin,GPIO.HIGH)
        else:
            print("Humidifier turning off.")
            GPIO.output(humidifierPin,GPIO.LOW)
        
    
    #print(current_time[0])
    
    time.sleep(5)
    
    
    
    
    
    